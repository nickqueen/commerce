from flask import Blueprint, request, jsonify
from src.repository.cart_repository import CartRepository
from src.dto.cart_dto import CartItemAddDTO, CartItemUpdateDTO
from src.middleware.auth_middleware import require_user

cart_bp = Blueprint('cart', __name__)
cart_repository = CartRepository()

@cart_bp.route('/cart', methods=['GET'])
@require_user
def get_cart():
    """Busca o carrinho do usuário atual"""
    try:
        user = request.current_user
        cart_dto = cart_repository.get_cart_dto(user.id)
        
        return jsonify({
            'cart': cart_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@cart_bp.route('/cart/items', methods=['POST'])
@require_user
def add_item_to_cart():
    """Adiciona item ao carrinho do usuário"""
    try:
        user = request.current_user
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or not all(k in data for k in ('product_id', 'quantity')):
            return jsonify({'error': 'product_id e quantity são obrigatórios'}), 400
        
        # Criar DTO
        item_dto = CartItemAddDTO(
            product_id=data['product_id'],
            quantity=data['quantity']
        )
        
        # Adicionar item
        cart_item = cart_repository.add_item_to_cart(user.id, item_dto)
        
        # Buscar carrinho atualizado
        cart_dto = cart_repository.get_cart_dto(user.id)
        
        return jsonify({
            'message': 'Item adicionado ao carrinho com sucesso',
            'cart': cart_dto.__dict__
        }), 201
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@cart_bp.route('/cart/items/<int:item_id>', methods=['PUT'])
@require_user
def update_cart_item(item_id):
    """Atualiza quantidade de item no carrinho"""
    try:
        user = request.current_user
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or 'quantity' not in data:
            return jsonify({'error': 'quantity é obrigatório'}), 400
        
        # Criar DTO
        item_dto = CartItemUpdateDTO(quantity=data['quantity'])
        
        # Atualizar item
        cart_item = cart_repository.update_cart_item(user.id, item_id, item_dto)
        
        if not cart_item:
            return jsonify({'error': 'Item não encontrado no carrinho'}), 404
        
        # Buscar carrinho atualizado
        cart_dto = cart_repository.get_cart_dto(user.id)
        
        return jsonify({
            'message': 'Item atualizado com sucesso',
            'cart': cart_dto.__dict__
        }), 200
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@cart_bp.route('/cart/items/<int:item_id>', methods=['DELETE'])
@require_user
def remove_cart_item(item_id):
    """Remove item do carrinho"""
    try:
        user = request.current_user
        
        success = cart_repository.remove_item_from_cart(user.id, item_id)
        
        if not success:
            return jsonify({'error': 'Item não encontrado no carrinho'}), 404
        
        # Buscar carrinho atualizado
        cart_dto = cart_repository.get_cart_dto(user.id)
        
        return jsonify({
            'message': 'Item removido do carrinho com sucesso',
            'cart': cart_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@cart_bp.route('/cart/clear', methods=['DELETE'])
@require_user
def clear_cart():
    """Limpa todos os itens do carrinho"""
    try:
        user = request.current_user
        
        success = cart_repository.clear_user_cart(user.id)
        
        if not success:
            return jsonify({'error': 'Carrinho não encontrado'}), 404
        
        # Buscar carrinho atualizado
        cart_dto = cart_repository.get_cart_dto(user.id)
        
        return jsonify({
            'message': 'Carrinho limpo com sucesso',
            'cart': cart_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@cart_bp.route('/cart/validate', methods=['GET'])
@require_user
def validate_cart():
    """Valida se o carrinho pode ser usado para compra"""
    try:
        user = request.current_user
        
        is_valid, errors = cart_repository.validate_cart_for_purchase(user.id)
        
        return jsonify({
            'is_valid': is_valid,
            'errors': errors
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

