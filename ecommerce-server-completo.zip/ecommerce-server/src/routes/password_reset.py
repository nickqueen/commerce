from flask import Blueprint, request, jsonify
from src.repository.user_repository import UserRepository
from src.service.email_service import email_service
from src.dto.user_dto import PasswordResetRequestDTO, PasswordResetDTO

password_reset_bp = Blueprint('password_reset', __name__)
user_repository = UserRepository()

@password_reset_bp.route('/forgot-password', methods=['POST'])
def request_password_reset():
    """Solicita recuperação de senha"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or 'email' not in data:
            return jsonify({'error': 'Email é obrigatório'}), 400
        
        # Criar DTO
        reset_dto = PasswordResetRequestDTO(email=data['email'])
        
        # Solicitar reset de senha
        reset_token = user_repository.request_password_reset(reset_dto.email)
        
        if not reset_token:
            # Por segurança, sempre retornar sucesso mesmo se o email não existir
            return jsonify({
                'message': 'Se o email estiver cadastrado, você receberá instruções para redefinir sua senha'
            }), 200
        
        # Buscar usuário para obter o username
        user = user_repository.get_user_by_email(reset_dto.email)
        
        # Verificar se o serviço de email está configurado
        if not email_service.is_configured():
            return jsonify({
                'message': 'Serviço de email não configurado. Token gerado para teste',
                'token': reset_token.token  # Apenas para desenvolvimento/teste
            }), 200
        
        # Enviar email
        email_sent = email_service.send_password_reset_email(
            to_email=user.email,
            username=user.username,
            reset_token=reset_token.token
        )
        
        if email_sent:
            return jsonify({
                'message': 'Instruções para redefinir sua senha foram enviadas para seu email'
            }), 200
        else:
            return jsonify({
                'message': 'Erro ao enviar email. Token gerado para teste',
                'token': reset_token.token  # Apenas para desenvolvimento/teste
            }), 200
            
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@password_reset_bp.route('/reset-password', methods=['POST'])
def reset_password():
    """Redefine a senha usando token"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or not all(k in data for k in ('token', 'new_password')):
            return jsonify({'error': 'Token e nova senha são obrigatórios'}), 400
        
        # Validar força da senha
        if len(data['new_password']) < 6:
            return jsonify({'error': 'A senha deve ter pelo menos 6 caracteres'}), 400
        
        # Criar DTO
        reset_dto = PasswordResetDTO(
            token=data['token'],
            new_password=data['new_password']
        )
        
        # Resetar senha
        success = user_repository.reset_password(reset_dto.token, reset_dto.new_password)
        
        if not success:
            return jsonify({'error': 'Token inválido ou expirado'}), 400
        
        return jsonify({
            'message': 'Senha redefinida com sucesso. Você pode fazer login com a nova senha'
        }), 200
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@password_reset_bp.route('/validate-reset-token', methods=['POST'])
def validate_reset_token():
    """Valida se um token de reset é válido"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or 'token' not in data:
            return jsonify({'error': 'Token é obrigatório'}), 400
        
        # Importar DAO diretamente para validação
        from src.dao.user_dao import UserDAO
        reset_token = UserDAO.get_valid_reset_token(data['token'])
        
        if not reset_token:
            return jsonify({'is_valid': False, 'error': 'Token inválido ou expirado'}), 200
        
        return jsonify({
            'is_valid': True,
            'expires_at': reset_token.expires_at.isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

