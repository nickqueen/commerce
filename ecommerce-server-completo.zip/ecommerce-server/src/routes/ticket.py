from flask import Blueprint, request, jsonify
from src.repository.ticket_repository import TicketRepository
from src.repository.cart_repository import CartRepository
from src.middleware.auth_middleware import require_user, require_admin
from src.models.ticket import TicketStatus

ticket_bp = Blueprint('ticket', __name__)
ticket_repository = TicketRepository()
cart_repository = CartRepository()

@ticket_bp.route('/purchase', methods=['POST'])
@require_user
def purchase():
    """Realiza compra a partir do carrinho do usuário"""
    try:
        user = request.current_user
        
        # Validar carrinho antes da compra
        is_valid, errors = cart_repository.validate_cart_for_purchase(user.id)
        
        if not is_valid:
            return jsonify({
                'error': 'Carrinho inválido para compra',
                'details': errors
            }), 400
        
        # Criar ticket a partir do carrinho
        ticket, is_complete = ticket_repository.create_ticket_from_cart(user.id)
        
        # Preparar resposta
        ticket_dto = ticket_repository.get_ticket_dto(ticket)
        
        if is_complete:
            message = 'Compra realizada com sucesso! Todos os itens foram processados.'
            status_code = 201
        else:
            message = 'Compra parcialmente realizada. Alguns itens não tinham estoque suficiente.'
            status_code = 206  # Partial Content
        
        return jsonify({
            'message': message,
            'ticket': ticket_dto.__dict__,
            'is_complete': is_complete
        }), status_code
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/tickets', methods=['GET'])
@require_user
def get_user_tickets():
    """Lista todos os tickets do usuário"""
    try:
        user = request.current_user
        
        # Parâmetros de consulta
        status = request.args.get('status')
        
        if status:
            try:
                status_enum = TicketStatus(status)
                tickets = [t for t in ticket_repository.get_user_tickets(user.id) if t.status == status_enum]
            except ValueError:
                return jsonify({'error': 'Status inválido'}), 400
        else:
            tickets = ticket_repository.get_user_tickets(user.id)
        
        # Converter para DTOs
        tickets_dto = [ticket_repository.get_ticket_dto(ticket).__dict__ for ticket in tickets]
        
        return jsonify({
            'tickets': tickets_dto,
            'total': len(tickets_dto)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/tickets/<int:ticket_id>', methods=['GET'])
@require_user
def get_ticket(ticket_id):
    """Busca um ticket específico do usuário"""
    try:
        user = request.current_user
        ticket = ticket_repository.get_ticket_by_id(ticket_id)
        
        if not ticket or ticket.user_id != user.id:
            return jsonify({'error': 'Ticket não encontrado'}), 404
        
        ticket_dto = ticket_repository.get_ticket_dto(ticket)
        
        return jsonify({
            'ticket': ticket_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/tickets/<int:ticket_id>/cancel', methods=['PATCH'])
@require_user
def cancel_ticket(ticket_id):
    """Cancela um ticket do usuário"""
    try:
        user = request.current_user
        ticket = ticket_repository.get_ticket_by_id(ticket_id)
        
        if not ticket or ticket.user_id != user.id:
            return jsonify({'error': 'Ticket não encontrado'}), 404
        
        if ticket.status == TicketStatus.CANCELLED:
            return jsonify({'error': 'Ticket já está cancelado'}), 400
        
        # Cancelar ticket
        cancelled_ticket = ticket_repository.cancel_ticket(ticket_id)
        
        if not cancelled_ticket:
            return jsonify({'error': 'Não foi possível cancelar o ticket'}), 400
        
        ticket_dto = ticket_repository.get_ticket_dto(cancelled_ticket)
        
        return jsonify({
            'message': 'Ticket cancelado com sucesso. Estoque restaurado.',
            'ticket': ticket_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/purchase-summary', methods=['GET'])
@require_user
def get_purchase_summary():
    """Retorna resumo de compras do usuário"""
    try:
        user = request.current_user
        summary = ticket_repository.get_purchase_summary(user.id)
        
        return jsonify({
            'summary': summary
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

# Rotas administrativas

@ticket_bp.route('/admin/tickets', methods=['GET'])
@require_admin
def get_all_tickets():
    """Lista todos os tickets (apenas admin)"""
    try:
        # Parâmetros de consulta
        status = request.args.get('status')
        user_id = request.args.get('user_id')
        
        if status:
            try:
                status_enum = TicketStatus(status)
                tickets = ticket_repository.get_tickets_by_status(status_enum)
            except ValueError:
                return jsonify({'error': 'Status inválido'}), 400
        elif user_id:
            try:
                user_id_int = int(user_id)
                tickets = ticket_repository.get_user_tickets(user_id_int)
            except ValueError:
                return jsonify({'error': 'User ID inválido'}), 400
        else:
            tickets = ticket_repository.get_all_tickets()
        
        # Converter para DTOs
        tickets_dto = [ticket_repository.get_ticket_dto(ticket).__dict__ for ticket in tickets]
        
        return jsonify({
            'tickets': tickets_dto,
            'total': len(tickets_dto)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/admin/tickets/<int:ticket_id>', methods=['GET'])
@require_admin
def get_ticket_admin(ticket_id):
    """Busca um ticket específico (apenas admin)"""
    try:
        ticket = ticket_repository.get_ticket_by_id(ticket_id)
        
        if not ticket:
            return jsonify({'error': 'Ticket não encontrado'}), 404
        
        ticket_dto = ticket_repository.get_ticket_dto(ticket)
        
        return jsonify({
            'ticket': ticket_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/admin/tickets/<int:ticket_id>/cancel', methods=['PATCH'])
@require_admin
def cancel_ticket_admin(ticket_id):
    """Cancela um ticket (apenas admin)"""
    try:
        ticket = ticket_repository.get_ticket_by_id(ticket_id)
        
        if not ticket:
            return jsonify({'error': 'Ticket não encontrado'}), 404
        
        if ticket.status == TicketStatus.CANCELLED:
            return jsonify({'error': 'Ticket já está cancelado'}), 400
        
        # Cancelar ticket
        cancelled_ticket = ticket_repository.cancel_ticket(ticket_id)
        
        if not cancelled_ticket:
            return jsonify({'error': 'Não foi possível cancelar o ticket'}), 400
        
        ticket_dto = ticket_repository.get_ticket_dto(cancelled_ticket)
        
        return jsonify({
            'message': 'Ticket cancelado com sucesso. Estoque restaurado.',
            'ticket': ticket_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@ticket_bp.route('/admin/statistics', methods=['GET'])
@require_admin
def get_statistics():
    """Retorna estatísticas gerais de tickets (apenas admin)"""
    try:
        all_tickets = ticket_repository.get_all_tickets()
        
        total_tickets = len(all_tickets)
        completed_tickets = len([t for t in all_tickets if t.status == TicketStatus.COMPLETED])
        partial_tickets = len([t for t in all_tickets if t.status == TicketStatus.PARTIAL])
        cancelled_tickets = len([t for t in all_tickets if t.status == TicketStatus.CANCELLED])
        pending_tickets = len([t for t in all_tickets if t.status == TicketStatus.PENDING])
        
        total_revenue = sum(float(t.total_amount) for t in all_tickets if t.status != TicketStatus.CANCELLED)
        
        statistics = {
            'total_tickets': total_tickets,
            'completed_tickets': completed_tickets,
            'partial_tickets': partial_tickets,
            'cancelled_tickets': cancelled_tickets,
            'pending_tickets': pending_tickets,
            'total_revenue': total_revenue,
            'completion_rate': (completed_tickets / total_tickets * 100) if total_tickets > 0 else 0
        }
        
        return jsonify({
            'statistics': statistics
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

