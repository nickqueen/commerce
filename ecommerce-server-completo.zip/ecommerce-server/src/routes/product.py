from flask import Blueprint, request, jsonify
from src.repository.product_repository import ProductRepository
from src.dto.product_dto import ProductCreateDTO, ProductUpdateDTO
from src.middleware.auth_middleware import require_admin, optional_auth

product_bp = Blueprint('product', __name__)
product_repository = ProductRepository()

@product_bp.route('/products', methods=['GET'])
@optional_auth
def get_products():
    """Lista todos os produtos ativos"""
    try:
        # Parâmetros de consulta
        category = request.args.get('category')
        search = request.args.get('search')
        
        if category:
            products = product_repository.get_products_by_category(category)
        elif search:
            products = product_repository.search_products(search)
        else:
            products = product_repository.get_active_products()
        
        # Converter para DTOs
        products_dto = [product_repository.get_product_dto(product).__dict__ for product in products]
        
        return jsonify({
            'products': products_dto,
            'total': len(products_dto)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products/<int:product_id>', methods=['GET'])
@optional_auth
def get_product(product_id):
    """Busca um produto específico"""
    try:
        product = product_repository.get_product_by_id(product_id)
        
        if not product or not product.is_active:
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        product_dto = product_repository.get_product_dto(product)
        
        return jsonify({
            'product': product_dto.__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products', methods=['POST'])
@require_admin
def create_product():
    """Cria um novo produto (apenas admin)"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or not all(k in data for k in ('name', 'price', 'stock')):
            return jsonify({'error': 'Name, price e stock são obrigatórios'}), 400
        
        # Criar DTO
        product_dto = ProductCreateDTO(
            name=data['name'],
            description=data.get('description'),
            price=data['price'],
            stock=data['stock'],
            image_url=data.get('image_url'),
            category=data.get('category')
        )
        
        # Criar produto
        product = product_repository.create_product(product_dto)
        
        return jsonify({
            'message': 'Produto criado com sucesso',
            'product': product_repository.get_product_dto(product).__dict__
        }), 201
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products/<int:product_id>', methods=['PUT'])
@require_admin
def update_product(product_id):
    """Atualiza um produto (apenas admin)"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados para atualização são obrigatórios'}), 400
        
        # Criar DTO
        product_dto = ProductUpdateDTO(
            name=data.get('name'),
            description=data.get('description'),
            price=data.get('price'),
            stock=data.get('stock'),
            image_url=data.get('image_url'),
            category=data.get('category'),
            is_active=data.get('is_active')
        )
        
        # Atualizar produto
        product = product_repository.update_product(product_id, product_dto)
        
        if not product:
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        return jsonify({
            'message': 'Produto atualizado com sucesso',
            'product': product_repository.get_product_dto(product).__dict__
        }), 200
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products/<int:product_id>', methods=['DELETE'])
@require_admin
def delete_product(product_id):
    """Deleta um produto (apenas admin)"""
    try:
        success = product_repository.delete_product(product_id)
        
        if not success:
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        return jsonify({
            'message': 'Produto deletado com sucesso'
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products/<int:product_id>/deactivate', methods=['PATCH'])
@require_admin
def deactivate_product(product_id):
    """Desativa um produto (soft delete - apenas admin)"""
    try:
        product = product_repository.deactivate_product(product_id)
        
        if not product:
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        return jsonify({
            'message': 'Produto desativado com sucesso',
            'product': product_repository.get_product_dto(product).__dict__
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@product_bp.route('/products/<int:product_id>/stock', methods=['PATCH'])
@require_admin
def update_stock(product_id):
    """Atualiza o estoque de um produto (apenas admin)"""
    try:
        data = request.get_json()
        
        if not data or 'stock' not in data:
            return jsonify({'error': 'Novo valor de estoque é obrigatório'}), 400
        
        product = product_repository.update_stock(product_id, data['stock'])
        
        if not product:
            return jsonify({'error': 'Produto não encontrado'}), 404
        
        return jsonify({
            'message': 'Estoque atualizado com sucesso',
            'product': product_repository.get_product_dto(product).__dict__
        }), 200
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

